CREATE PROCEDURE addDep(IN depName VARCHAR(32), IN parentId INT, IN enabled TINYINT(1), OUT result INT, OUT result2 INT)
  begin
  declare did int;
  declare pDepPath varchar(64);
  insert into department set name=depName,parentId=parentId,enabled=enabled;
  select row_count() into result;
  select last_insert_id() into did;
  set result2=did;
  select depPath into pDepPath from department where id=parentId;
  update department set depPath=concat(pDepPath,'.',did) where id=did;
  update department set isParent=true where id=parentId;
end;

